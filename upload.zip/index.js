/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./services/ColorService.js
/**
 * ColorService - Responsible for color-related operations
 * Following the Single Responsibility Principle
 */
/**
 * Implementation of the color service
 */
class ColorService {
    /**
     * Determines the contrast text color (black or white) based on background color
     * @param backgroundColor - The background color in hex format (without # prefix)
     * @returns The contrast text color in hex format including # prefix
     */
    getContrastTextColor(backgroundColor) {
        // Parse the red component and check if it's bright enough for black text
        return ((parseInt(backgroundColor, 16) >> 16) & 0xff) > 0xaa
            ? "#000000"
            : "#ffffff";
    }
}
// Singleton instance for convenient usage
const colorService = new ColorService();
/* harmony default export */ const services_ColorService = (colorService);
//# sourceMappingURL=ColorService.js.map
;// CONCATENATED MODULE: ./services/ParamService.js
/**
 * Implementation of the parameter service
 * Uses dependency inversion by depending on abstractions
 */
class ParamService {
    params = [];
    /**
     * Defines parameters for the fxhash project
     * @param params - Array of parameter definitions
     */
    defineParams(params) {
        this.params.length = 0; // Clear array without creating a new instance
        this.params.push(...params); // Add new params
        window.$fx.params(params);
    }
    /**
     * Defines features for the fxhash project
     * @param features - Record of feature definitions
     */
    defineFeatures(features) {
        window.$fx.features(features);
    }
    /**
     * Gets random values for all parameters
     * @returns Object containing random values for each parameter
     */
    getRandomParams() {
        const randomParams = {};
        for (const param of this.params) {
            randomParams[param.id] = window.$fx.getRandomParam(param.id);
        }
        return randomParams;
    }
}
// Singleton instance for convenient usage
const paramService = new ParamService();
/* harmony default export */ const services_ParamService = (paramService);
//# sourceMappingURL=ParamService.js.map
;// CONCATENATED MODULE: ./models/Parameters.js
/**
 * Parameters model for fxhash project
 * Following SOLID principles, this model focuses only on parameter structure
 */
/**
 * Factory function to create parameters
 */
const createNumberParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'number',
    options,
    ...(defaultValue !== undefined && { default: defaultValue }),
});
const createBigIntParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'bigint',
    update: 'code-driven',
    options,
    ...(defaultValue !== undefined && { default: defaultValue }),
});
const createStringParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'string',
    update: 'code-driven',
    options,
    ...(defaultValue !== undefined && { default: defaultValue }),
});
const createSelectParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'select',
    update: 'code-driven',
    options: { options },
    ...(defaultValue !== undefined && { default: defaultValue }),
});
const createColorParameter = (id, name, defaultValue) => ({
    id,
    name,
    type: 'color',
    update: 'code-driven',
    ...(defaultValue !== undefined && { default: defaultValue }),
});
const createBooleanParameter = (id, name, defaultValue) => ({
    id,
    name,
    type: 'boolean',
    update: 'code-driven',
    ...(defaultValue !== undefined && { default: defaultValue }),
});
//# sourceMappingURL=Parameters.js.map
;// CONCATENATED MODULE: ./index.js
/**
 * Main entry point for the fxhash project
 * Implements the original functionality with TypeScript and SOLID principles
 */
// Import services


// Import parameter factory functions

/**
 * Define all the parameters for the project
 */
const defineParameters = () => {
    const params = [
        createNumberParameter("number_id", "A number/float64", {
            min: 1,
            max: 10,
            step: 0.0001,
        }),
        createBigIntParameter("bigint_id", "A bigint", {
            min: Number.MIN_SAFE_INTEGER * 4,
            max: Number.MAX_SAFE_INTEGER * 4,
            step: 1,
        }),
        createStringParameter("string_id_long", "A string long", {
            minLength: 1,
            maxLength: 512,
        }),
        createSelectParameter("select_id", "A selection", ["apple", "orange", "pear"]),
        createColorParameter("color_id", "A color"),
        createBooleanParameter("boolean_id", "A boolean"),
        createStringParameter("string_id", "A string", {
            minLength: 1,
            maxLength: 512,
        }),
    ];
    services_ParamService.defineParams(params);
};
/**
 * Define features for the project
 */
const defineFeatures = () => {
    services_ParamService.defineFeatures({
        "A random feature": Math.floor($fx.rand() * 10),
        "A random boolean": $fx.rand() > 0.5,
        "A random string": ["A", "B", "C", "D"].at(Math.floor($fx.rand() * 4)),
        "Feature from params, its a number": $fx.getParam("number_id"),
    });
};
/**
 * Update the document based on the parameters
 */
const updateDocument = () => {
    const bgcolor = $fx.getParam("color_id").hex.rgba;
    const textcolor = services_ColorService.getContrastTextColor(bgcolor.replace("#", ""));
    // Update the document based on the parameters
    document.body.style.background = bgcolor;
    document.body.innerHTML = `
  <div style="color: ${textcolor};">
    <p>
    hash: ${$fx.hash}
    </p>
    <p>
    minter: ${$fx.minter}
    </p>
    <p>
    iteration: ${$fx.iteration}
    </p>
    <p>
    inputBytes: ${$fx.inputBytes}
    </p>
    <p>
    context: ${$fx.context}
    </p>
    <p>
    params:
    </p>
    <pre>
    ${$fx.stringifyParams($fx.getRawParams())}
    </pre>
  <div>
  `;
    // Create button to emit random params
    const btn = document.createElement("button");
    btn.textContent = "emit random params";
    btn.addEventListener("click", handleRandomizeClick);
    document.body.appendChild(btn);
};
/**
 * Handle click on the randomize button
 */
const handleRandomizeClick = () => {
    $fx.emit("params:update", services_ParamService.getRandomParams());
    main();
};
/**
 * Main function to initialize the project
 */
const main = () => {
    updateDocument();
};
/**
 * Initialize the project
 */
const initialize = () => {
    defineParameters();
    defineFeatures();
    main();
    // Set up event listeners
    $fx.on("params:update", (newRawValues) => {
        // opt-out default behaviour
        if (newRawValues.number_id === 5)
            return false;
        // opt-in default behaviour
        return true;
    }, (optInDefault, newValues) => main());
};
// Run initialization when DOM is fully loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
}
else {
    initialize();
}
//# sourceMappingURL=index.js.map
/******/ })()
;