/**
 * ColorService - Responsible for color-related operations
 * Following the Single Responsibility Principle
 */
/**
 * Implementation of the color service
 */
export class ColorService {
    /**
     * Determines the contrast text color (black or white) based on background color
     * @param backgroundColor - The background color in hex format (without # prefix)
     * @returns The contrast text color in hex format including # prefix
     */
    getContrastTextColor(backgroundColor) {
        // Parse the red component and check if it's bright enough for black text
        return ((parseInt(backgroundColor, 16) >> 16) & 0xff) > 0xaa
            ? "#000000"
            : "#ffffff";
    }
}
// Singleton instance for convenient usage
const colorService = new ColorService();
export default colorService;
//# sourceMappingURL=ColorService.js.map