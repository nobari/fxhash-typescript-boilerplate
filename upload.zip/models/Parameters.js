/**
 * Parameters model for fxhash project
 * Following SOLID principles, this model focuses only on parameter structure
 */
/**
 * Factory function to create parameters
 */
export const createNumberParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'number',
    options,
    ...(defaultValue !== undefined && { default: defaultValue }),
});
export const createBigIntParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'bigint',
    update: 'code-driven',
    options,
    ...(defaultValue !== undefined && { default: defaultValue }),
});
export const createStringParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'string',
    update: 'code-driven',
    options,
    ...(defaultValue !== undefined && { default: defaultValue }),
});
export const createSelectParameter = (id, name, options, defaultValue) => ({
    id,
    name,
    type: 'select',
    update: 'code-driven',
    options: { options },
    ...(defaultValue !== undefined && { default: defaultValue }),
});
export const createColorParameter = (id, name, defaultValue) => ({
    id,
    name,
    type: 'color',
    update: 'code-driven',
    ...(defaultValue !== undefined && { default: defaultValue }),
});
export const createBooleanParameter = (id, name, defaultValue) => ({
    id,
    name,
    type: 'boolean',
    update: 'code-driven',
    ...(defaultValue !== undefined && { default: defaultValue }),
});
//# sourceMappingURL=Parameters.js.map