/**
 * Implementation of the parameter service
 * Uses dependency inversion by depending on abstractions
 */
export class ParamService {
    params = [];
    /**
     * Defines parameters for the fxhash project
     * @param params - Array of parameter definitions
     */
    defineParams(params) {
        this.params.length = 0; // Clear array without creating a new instance
        this.params.push(...params); // Add new params
        window.$fx.params(params);
    }
    /**
     * Defines features for the fxhash project
     * @param features - Record of feature definitions
     */
    defineFeatures(features) {
        window.$fx.features(features);
    }
    /**
     * Gets random values for all parameters
     * @returns Object containing random values for each parameter
     */
    getRandomParams() {
        const randomParams = {};
        for (const param of this.params) {
            randomParams[param.id] = window.$fx.getRandomParam(param.id);
        }
        return randomParams;
    }
}
// Singleton instance for convenient usage
const paramService = new ParamService();
export default paramService;
//# sourceMappingURL=ParamService.js.map